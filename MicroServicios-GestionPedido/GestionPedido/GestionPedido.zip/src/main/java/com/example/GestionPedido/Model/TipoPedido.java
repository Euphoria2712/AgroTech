package com.example.GestionPedido.Model;

public enum TipoPedido {
    PENDIENTE,
    EN_PREPARACION,
    ENVIADO,
    ENTREGADO,
    CANCELADO
}