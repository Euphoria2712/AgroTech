package com.example.GestionPedido.Model;

public enum EstadoPedido {
    PENDIENTE,
    EN_PREPARACION,
    ENVIADO,
    ENTREGADO,
    CANCELADO
}