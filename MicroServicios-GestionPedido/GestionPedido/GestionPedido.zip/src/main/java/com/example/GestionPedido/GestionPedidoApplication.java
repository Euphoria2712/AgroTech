package com.example.GestionPedido;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionPedidoApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionPedidoApplication.class, args);
	}

}
