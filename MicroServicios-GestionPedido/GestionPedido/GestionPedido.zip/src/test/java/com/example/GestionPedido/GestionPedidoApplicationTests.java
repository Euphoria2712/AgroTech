package com.example.GestionPedido;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionPedidoApplicationTests {

	@Test
	void contextLoads() {
	}

}
