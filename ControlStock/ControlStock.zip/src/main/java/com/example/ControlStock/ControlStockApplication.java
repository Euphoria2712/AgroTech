package com.example.ControlStock;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControlStockApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControlStockApplication.class, args);
	}

}
