package com.example.ControlStock.Model;

import lombok.Data;

@Data
public class ConsultaStockRequest {

    private Long productoId;

}
