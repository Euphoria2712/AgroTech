package com.example.ControlStock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControlStockApplicationTests {

	@Test
	void contextLoads() {
	}

}
